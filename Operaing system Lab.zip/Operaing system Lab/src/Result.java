
public class Result {
	private long value;
	
	public void setValue(long v) {
		value = v;
	}
	public long getValue() {
		return value;
		
	}
}