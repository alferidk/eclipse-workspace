import java.util.Random;

public class Main{
	public static void main(String[] args)  {
		int n = Integer.parseInt(args[0]);
		int[] nums = new int [n];
		Random r = new Random();
		
		for (int i=0; i<nums.length;i++) {
			nums[i]= r.nextInt(1000);
		}
		
		  Result rSum = new Result();
		 Thread th0 = new Thread(new Sum(rSum, nums));
		 Result rMax = new Result();
		 Thread th1 = new Thread(new Max(rMax, nums));
		 Result rMin = new Result();
		 Thread th2 = new Thread(new Min(rMin, nums));
		 
		 
		 th0.start();
		 th1.start();
		 th2.start();
		 
		 try {
			  th0.join();
			  th1.join();
			  th2.join();
			  
			  System.out.printf("We made a bunch of random numbers, the sum is %d%n", rSum.getValue());
			  System.out.printf("We made a bunch of random numbers, the max is %d%n", rMax.getValue());
			  System.out.printf("We made a bunch of random numbers, the min is %d%n", rMin.getValue());
		 } catch (InterruptedException ex) {
		    System.err.println("Unable to join");
		    
		 }
		 
	 }
 }