
	public class Sum implements Runnable {
		private Result rSum;
		private int[]nums;
		public Sum (Result rsum,int[]nums1) {
			rSum=rsum;
			nums=nums1;
		
		}
		
		
		public void run () {
			long sum = 0;
			 for (int i=0;i<nums.length; i++) {
				 sum = sum + nums [i];
			 }
			 rSum.setValue(sum);
		}
		
		}