import java.text.DecimalFormat;
	import java.util.*;

	public class RoundRobin{
		private static Queue<Task> queue;
		private static ArrayList<Task> proc;
		private static int quant, tickCount = 0;
		private static int[] burstTimes;  
		private static String gantt = "";
		
		 
		public static String run(ArrayList<Task> p, int q) {
			 
			queue = new LinkedList<Task>();
			proc = p;
			quant = q;
			burstTimes = new int[proc.size()];
			
			for(int i = 0; i < proc.size(); i++) {
				burstTimes[i] = proc.get(i).getBurst();
			}
			
			 
			if(proc.get(0).getArrival() == 0) {
				int index = 0;
				do {
					queue.add(proc.get(index));
					index++;
				} while(proc.get(index-1).getArrival() == proc.get(index).getArrival()); 
			}
			 
			while(!done()) {
				tick();
			} 
			
			
			DecimalFormat df = new DecimalFormat("#.00");
			double avgWait = 0;
			double avgTurnaround = 0;
			for(Task pX : proc) {
				avgWait += pX.getWait();
				avgTurnaround += pX.getTurnaround();
			}
			avgWait = avgWait / proc.size();
			avgTurnaround = avgTurnaround / proc.size();
			
			
			 
			return "\nAll processes completed in " + tickCount + " ticks!"
					+ "\nAverage wait time was: " + df.format(avgWait)
					+ "\nAverage turnaround time was: " + df.format(avgTurnaround)
					+ "\nGantt Chart: 1 dash = 1 tick\n" + gantt +"|";
			
		} 
		
		 
		private static void tick() {
			 
			int current = proc.indexOf(queue.peek());
			
 			gantt += "|" + proc.get(current).getName();
			for(int i = 0; i < quant; i++) {
				tickCount++;
				System.out.println("Tick!");
				gantt += "-";
				

				for(Task pX : proc) {
					if(pX.getArrival() == tickCount) {
						queue.add(pX);
					}
				}
				 
				burstTimes[current]--;
				
				 
				if(burstTimes[current] == 0) {
					break;
				}
				 
				try { 
					Thread.sleep(500); 
				} catch (Exception e) { 
					System.err.println(e); 
				}
				
			}
			 
			if(burstTimes[current] == 0) {
				try {
					queue.remove();
				} catch (NoSuchElementException e) {
					System.out.println("Some error occured...");
				}
				proc.get(current).setCompletion(tickCount);
				proc.get(current).fill();
				System.out.println("Process " + proc.get(current).getName() + " completed!");
			} else {
				queue.add(queue.remove());
			}
			
		} 
		
	 
		private static boolean done() {
			boolean done = true;
			for(int i = 0; i < burstTimes.length; i++) {
				if(burstTimes[i] != 0) {
					done = false;
					break;
				}
			}
				
			return done;
		}  
		
	}  





