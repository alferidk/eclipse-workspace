
 
 
	 
	public class Task {
		private String name;
		private int arrival, burst, completion, turnaround, wait;
		
 
		
		public Task(String N, int A, int B) {
			this.name = N;
			this.arrival = A;
			this.burst = B;
		}
		
		 
		public void fill() {
			this.turnaround = completion - arrival;
			this.wait = turnaround - burst;
		}

		 
		public String getName() {
			return name;
		}
		
		 
		public int getArrival() {
			return arrival;
		}

		 
		public int getBurst() {
			return burst;
		}

	 
		public void setCompletion(int completion) {
			this.completion = completion;
		}
		
		 
		public int getTurnaround() {
			return turnaround;
		}

		 
		public int getWait() {
			return wait;
		}

	}



