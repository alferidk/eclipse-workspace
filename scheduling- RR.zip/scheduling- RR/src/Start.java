import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Start {
	
	public static void startSchedulerFromFile(File inputFile) {
		try {
			BufferedReader fileReader = new BufferedReader(new FileReader(inputFile));
			ArrayList<Task> tasks = new ArrayList<Task>(); // queue for tasks
			
			String next;
			while((next = fileReader.readLine()) != null) { 
				
				// add each new process task to the queue for round robin scheduler
				if(next.length() > 0 && next.charAt(0) != 35) { 
					if(next.length() > 1) { 
						String[] split = next.split(" ", 3);
						String name = split[0];
						int arrivalTime = Integer.parseInt(split[1]);
						int burstTime = Integer.parseInt(split[2]);
						Task task = new Task(name, arrivalTime, burstTime);
						tasks.add(task);
					} else { 
						break;
					}
				}
			} 
			
			int quant = Character.getNumericValue(next.charAt(0));
			Collections.sort(tasks, new Comparator<Task>() {
				public int compare(Task p1, Task p2) {
					return p1.getArrival() - p2.getArrival();
				}
			});
			
			System.out.println("Starting round robin scheduler with quantum time " + quant + "\n");
			System.out.println(RoundRobin.run(tasks, quant));

			fileReader.close(); 
			
		} catch (Exception e) {
			System.err.println(e);
		}
	}
	
}
