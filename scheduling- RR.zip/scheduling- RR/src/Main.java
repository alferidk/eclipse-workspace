import java.util.Scanner;
import java.io.File;

public class Main {
	
	 public static void main(String[] args) {
			Scanner in = new Scanner(System.in);
			System.out.print("Please enter the name of the input file.\n");
			File input = new File(in.next() + ".txt");
			Start.startSchedulerFromFile(input);
			in.close();
		} 
}

