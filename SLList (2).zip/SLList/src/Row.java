public class  Row implements Runnable {
	private Result rRow;
	private int[][] my2DArray;
	public Row (Result rRown1,int[][] my2DArray1) {
		rRow = rRown1;
		my2DArray= my2DArray1;
	
	}
	
	
	public void run () {
		boolean Row = true;
		for (int i = 0; i < 9; i++) {
			boolean[]myArray = new boolean [9];
			for (int j = 0; j < 9; j++) {
				int number = my2DArray[i][j];
				myArray[number -1]= true;
			}

			for (int j = 0; j < 9; j++) {
				Row = myArray[j] && Row;
		}
		rRow.setValue(Row);
	}
}
}