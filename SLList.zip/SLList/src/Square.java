 public class  Square implements Runnable {
	private Result rSquare;
	private int[][] my2DArray;
	public Square (Result rSquare1,int[][] my2DArray1) {
		rSquare = rSquare1;
		my2DArray= my2DArray1;
	
	}
	
	
	public void run () {
		boolean Square  = true;
		int[] iCoords = {0,0,0,3,3,3,6,6,6};
		int[]jCoords =  {0,3,6,0,3,6,0,3,6};
		for (int k =0; k <9; k++) {
			boolean[]myArray = new boolean [9];
			for (int i = iCoords[k]; i <iCoords[k]+3; i++) {
				
				
				for (int j = jCoords[k]; j < jCoords[k]+3; j++) {

					int number = my2DArray[i][j];
					myArray[number -1]= true;
				}
				

				
			}
			for (int j = 0; j < 9; j++) {
				Square = myArray[j] && Square;
			}

		}
		rSquare.setValue(Square);
	}
}
