import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;
import java.util.Arrays;
import java.util.Timer;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		Random r = new Random();
		int[][] my2DArray = new int[9][9];
		Scanner Kbin = new Scanner(new File("easy.txt"));

		while (Kbin.hasNextLine()) {
			for (int i = 0; i < 9; i++) {
				String s = Kbin.next();
				String[] num = (s.split("-"));
				for (int j = 0; j < 9; j++) {
					my2DArray[i][j] = Integer.parseInt(num[j]);
				}
			}

		}
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				System.out.print(my2DArray[i][j] + " ");
			}
			System.out.println();
		}

		Result rRow = new Result();
		Thread th0 = new Thread(new Row(rRow, my2DArray));
		Result rColumn = new Result();
		Thread th1 = new Thread(new Column(rColumn, my2DArray));
		Result rSquare = new Result();
		Thread th2 = new Thread(new Square(rSquare, my2DArray));

		th0.start();
		th1.start();
		th2.start();

		try {
			th0.join();
			th1.join();
			th2.join();

			System.out.println(rRow.getValue());
			System.out.println(rColumn.getValue());
			System.out.println(rSquare.getValue());

		} catch (InterruptedException ex) {
			System.err.println("Unable to join");

		}
	}
}
