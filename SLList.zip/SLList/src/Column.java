public class  Column implements Runnable {
	private Result rColumn;
	private int[][] my2DArray;
	public Column (Result rColumn1,int[][] my2DArray1) {
		rColumn = rColumn1;
		my2DArray= my2DArray1;
	
	}
	
	
	public void run () {
		boolean Column  = true;
		for (int i = 0; i < 9; i++) {
			boolean[]myArray = new boolean [9];
			for (int j = 0; j < 9; j++) {
				int number = my2DArray[i][j];
				myArray[number -1]= true;
			}

			for (int j = 0; j < 9; j++) {
				Column = myArray[j] && Column;
			}

		
		}
		rColumn.setValue(Column);
	}
}
