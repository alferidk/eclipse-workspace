
public class Result {
private boolean value;
	
	public void setValue(boolean v) {
		value = v;
	}
	public boolean getValue() {
		return value;
		
	}
}
