import java.io.*;
import java.net.*;
import java.util.Scanner;

public class UDPCLIENT {
	
	private static DatagramSocket DS;
	private static DatagramSocket serversocket;
	public static void main(String args[]) throws IOException
	{
		Scanner in = new Scanner(System.in);
		int serverport=2228;
		int clientport=2229;
		int buffer_size=256;
 
		DS =new DatagramSocket();
		serversocket = new DatagramSocket(clientport);
 
		byte sendbuffer[] = null;
		byte buffer[]=new byte[buffer_size];

		int pos=0;
		while(true)
		{
			DatagramPacket dp=new DatagramPacket(buffer,buffer.length);
			serversocket.receive(dp); 
			System.out.println("msg received by server:");
			System.out.println(new String(dp.getData(),0,dp.getLength()));
 
			String input = in.next();
			sendbuffer = input.getBytes();
 
			
			DS.send(new DatagramPacket(sendbuffer,sendbuffer.length,InetAddress.getLocalHost(),serverport));
			
		}
 
	}
	 
	public void close() {
		DS.close();
	}

}


