public class  Max implements Runnable {
		private Result rMax;
		private int[]nums;
		public Max (Result rmax,int[]nums1) {
			rMax=rmax;
			nums=nums1;
		
		}
		
		
		public void run () {
			long Max = nums [0];
			 for (int i=1;i<nums.length; i++) {
			if (nums[i]> Max) {
				Max = nums[i];
			}
			 }
			 rMax.setValue(Max);
		}
}
		