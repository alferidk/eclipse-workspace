public class  Min implements Runnable {
		private Result rMin;
		private int[]nums;
		public Min (Result rmin,int[]nums1) {
			rMin=rmin;
			nums=nums1;
		
		}
		
		
		public void run () {
			long Min = nums [0];
			 for (int i=1;i<nums.length; i++) {
			if (nums[i]< Min) {
				Min = nums[i];
			}
			 }
			 rMin.setValue(Min);
		}
}
		
