/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab;

import java.util.Scanner;

/**
 *
 * @author ankemal0
 */
public class Lab4 {
    
     public static void test(){
         Scanner kbin = new Scanner(System.in);
         String s = kbin.next().trim();
         isPalindrome(s);
         System.out.println(isPalindrome(s));
     
     }

    public static boolean isPalindrome(String s) {
        if (s.length() == 1) {
            return true;
        }
        else if(s.length() == 0){
         return true;
        }
            else {
            if (s.charAt(0) == s.charAt(s.length() - 1)) {
                String shorterS = s.substring(1, s.length() - 1).trim();
                System.out.println(shorterS);
                return isPalindrome(shorterS);
            } else {
                 
            }
        }
    return false;
    }
    
}
