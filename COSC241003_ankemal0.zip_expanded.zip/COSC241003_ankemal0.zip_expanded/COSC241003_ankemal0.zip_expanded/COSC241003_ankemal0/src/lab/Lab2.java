/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



package lab;
import java.util.Vector;
import collection.MyVector;

public class Lab2 {
    
  
   /**
    * Function to test the basic functionalities of a vector
    */
        public static void test(){
            
        MyVector  v = new MyVector();//Instance of MyVector
           
        int num1 = 0;
        int num2 = 1;
        
        int num3;
        
        v.append(num1);//add the first 2 Fibonacci numbers 
        v.append(num2);     
        
        for ( int i = 2; i < 25; i++) {
            
            num3 = num1 + num2;           
            v.append(num3); //add the remaining 23 Fibonacci numbers making up 30 numbers   
            num1 = num2;
            num2 = num3;
          
            
        }
        
        System.out.println(v.toString()); //print out the vector
        System.out.println();
        
        v.reverse(); //reverse all the elements
        
        MyVector vClone = v.clone(); //make a clone of the vector
        
        System.out.println(v.toString()); //print out the original vector
        
        
    for (int i = v.size() - 1; i > 0; i--){
    
            if(i%2==1){
        
        v.removeAt(i); //remove all the elements at any odd index of the original vector
    }
    }
   System.out.println(v.toString());//print out the original vector
   
   
          vClone.reverse();//reverse the cloned vector
          
         System.out.println();
         System.out.println(vClone.toString());//print out the cloned vector 
         System.out.println();
        v.merge(vClone);//Merge the cloned vector with the original vector
        
        System.out.println(v.toString());//print out the original vector
        
}
        }
        