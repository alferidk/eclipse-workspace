/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab;
import java.util.*;
import collection.MySort;
import collection.MyVector;

/**
 *
 * @author ankemal0
 */
public class Lab5 {
    public static void test (){
        
        MyVector danVec = new MyVector();
        Random b = new Random ();
        int left=0;
        int right=0;
        Comparable[] temp = new Comparable[30000];
        
    
    b.setSeed(20181010);
    for (int k = 0; k < 30000; k++){
         danVec.append(b.nextInt(99999 + 0));
}
    
    long w1 = System.currentTimeMillis();
    MySort.bubbleSort(danVec);
    long w2 = System.currentTimeMillis();
    long difference = w2 - w1;
    System.out.println("The difference in the for Bubble Sort is:" + difference);
    System.out.println("Element at index 0:"+ danVec.elementAt(0));
    System.out.println("Element at index 1:"+ danVec.elementAt(1));
    System.out.println("Element at index 2:"+ danVec.elementAt(2));
    System.out.println("Element at index 9999:"+ danVec.elementAt(9999));
    System.out.println("Element at index 19999:"+ danVec.elementAt(19999));
    System.out.println("Element at index 29999:"+ danVec.elementAt(29999));
    System.out.println(" ");
    
    
    danVec.clear();
    
 b.setSeed(20181010);
    for (int k = 0; k < 30000; k++){
         danVec.append(b.nextInt(99999 + 0));
}
    
    w1 = System.currentTimeMillis();
    MySort.selectionSort(danVec);
     w2 = System.currentTimeMillis();
    difference = w2 - w1;
    System.out.println("The difference in the for Selectipon Sort is:" + difference);
    System.out.println("Element at index 0:"+ danVec.elementAt(0));
    System.out.println("Element at index 1:"+ danVec.elementAt(1));
    System.out.println("Element at index 2:"+ danVec.elementAt(2));
    System.out.println("Element at index 9999:"+ danVec.elementAt(9999));
    System.out.println("Element at index 19999:"+ danVec.elementAt(19999));
    System.out.println("Element at index 29999:"+ danVec.elementAt(29999));
    System.out.println(" ");

  danVec.clear();
b.setSeed(20181010);
    for (int k = 0; k < 30000; k++){
         danVec.append(b.nextInt(99999 + 0));
}
    
    w1 = System.currentTimeMillis();
     MySort.mergeSort(danVec, temp, left, right);
     
     w2 = System.currentTimeMillis();
    difference = w2 - w1;
    System.out.println("The difference in the for Merge Sort is:" + difference);
    System.out.println("Element at index 0:"+ danVec.elementAt(0));
    System.out.println("Element at index 1:"+ danVec.elementAt(1));
    System.out.println("Element at index 2:"+ danVec.elementAt(2));
    System.out.println("Element at index 9999:"+ danVec.elementAt(9999));
    System.out.println("Element at index 19999:"+ danVec.elementAt(19999));
    System.out.println("Element at index 29999:"+ danVec.elementAt(29999));
    System.out.println(" ");
    danVec.clear();
    
    
    b.setSeed(20181010);
    for (int k = 0; k < 30000; k++){
         danVec.append(b.nextInt(99999 + 0));
}
    
    w1 = System.currentTimeMillis();
    MySort.quickSort(danVec, left, right);
     w2 = System.currentTimeMillis();
    difference = w2 - w1;
    System.out.println("The difference in the for Quick Sort is:" + difference);
    System.out.println("Element at index 0:"+ danVec.elementAt(0));
    System.out.println("Element at index 1:"+ danVec.elementAt(1));
    System.out.println("Element at index 2:"+ danVec.elementAt(2));
    System.out.println("Element at index 9999:"+ danVec.elementAt(9999));
    System.out.println("Element at index 19999:"+ danVec.elementAt(19999));
    System.out.println("Element at index 29999:"+ danVec.elementAt(29999));
    System.out.println(" ");
    danVec.clear();
    
    
    b.setSeed(20181010);
    for (int k = 0; k < 30000; k++){
         danVec.append(b.nextInt(99999 + 0));
}
    
    w1 = System.currentTimeMillis();
    MySort.insertionSort(danVec, left, right);
     w2 = System.currentTimeMillis();
    difference = w2 - w1;
    System.out.println("The difference in the for insertion Sort is:" + difference);
    System.out.println("Element at index 0:"+ danVec.elementAt(0));
    System.out.println("Element at index 1:"+ danVec.elementAt(1));
    System.out.println("Element at index 2:"+ danVec.elementAt(2));
    System.out.println("Element at index 9999:"+ danVec.elementAt(9999));
    System.out.println("Element at index 19999:"+ danVec.elementAt(19999));
    System.out.println("Element at index 29999:"+ danVec.elementAt(29999));
    System.out.println(" ");
    danVec.clear();
    
     b.setSeed(20181010);
    for (int k = 0; k < 30000; k++){
         danVec.append(b.nextInt(99999 + 0));
}
    
    w1 = System.currentTimeMillis();
    MySort. shellSort(danVec);
     w2 = System.currentTimeMillis();
    difference = w2 - w1;
    System.out.println("The difference in the for shell Sort is:" + difference);
    System.out.println("Element at index 0:"+ danVec.elementAt(0));
    System.out.println("Element at index 1:"+ danVec.elementAt(1));
    System.out.println("Element at index 2:"+ danVec.elementAt(2));
    System.out.println("Element at index 9999:"+ danVec.elementAt(9999));
    System.out.println("Element at index 19999:"+ danVec.elementAt(19999));
    System.out.println("Element at index 29999:"+ danVec.elementAt(29999));
    System.out.println(" ");
}
}
