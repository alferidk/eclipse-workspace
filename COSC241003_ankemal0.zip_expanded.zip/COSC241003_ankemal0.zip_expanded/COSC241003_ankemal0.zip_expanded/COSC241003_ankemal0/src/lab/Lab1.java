/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab;
import java.util.*;
/**
 *
 * @author ankemal0
 */

public class Lab1 {
   public static void test(String[] args){ 
       
       Vector<Object> vector = new Vector<Object>();
       int primitiveInt = 241;
       Integer wrapperInt = new Integer (2018);
       String str = "Alferid Kemal";
       vector.add(primitiveInt);
       vector.add(wrapperInt);
       vector.add(str);
       vector.add(2, new Integer(2188));
       System.out.println("The elements pf vector: " + vector);
       System.out.println("The sixe of vector is: "
                                    + vector.size()) ;
       System.out.println("The element at position 2 is: "
                                    + vector.elementAt(2));
       System.out.println("The first element of vector is: "
                                    + vector.firstElement());
       System.out.println("The last element of vector is: "
                                     +vector.lastElement());
       vector.removeElementAt(1);
       System.out.println("The elements of vector: " + vector);
       System.out.println("The size of vector is: "
                                  + vector.size());
       System.out.println("The elemnets at position 2 is: "
                                     +vector. elementAt(2));
       System.out.println("The first elements of vector is: "
                                        + vector.firstElement());
       System.out.println("The last element of vector is: "
                                        + vector.lastElement());
       vector.clear();
       
       
       
       for(int i = 0; i < args.length; i++){
           
           vector.add(Integer.valueOf(args[i]));
      }
         System.out.println("The elements pf vector: " + vector);
      for(int i = vector.size();i >0; i--){
          if( i % 2 !=0){
              
              vector.removeElementAt(i);
          }
      }
      
        System.out.println("The elements pf vector: " + vector);
       

}
}
    
