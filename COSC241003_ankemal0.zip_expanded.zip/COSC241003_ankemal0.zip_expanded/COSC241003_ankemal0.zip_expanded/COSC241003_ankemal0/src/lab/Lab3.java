package lab;
import java.util.Vector;
import collection.*;
import collection.MyVector;
import static collection.MySort.bubbleSort;
import static collection.MySort.selectionSort;
import static collection.MySearch.binarySearch;
import static collection.MySearch.binarySearch;
import java.util.Random;
import java.util.Scanner;

public class Lab3 {
    
   
    public static void test(){
        
        MyVector numVec = new MyVector();
        Random rand = new Random();
        rand.setSeed(System.nanoTime());
        for (int i=0; i<900; i++){            
            numVec.append(rand.nextInt(1000)+100);
            
        }
        
       bubbleSort(numVec);
       
       System.out.print(numVec.toString());
       
       Scanner input = new Scanner(System.in);
       System.out.println();
       System.out.println("Please enter a number you wish to search for");
       int userInput = input.nextInt(); 
       
        System.out.println(binarySearch(numVec, userInput));
        
        numVec.removeRange(50, 550);
        
       numVec.reverse();
      
        selectionSort(numVec);
        System.out.println();
        System.out.print(numVec.toString());
        
        System.out.println("Please enter a number you wish to search for");
        int userInput2 = input.nextInt(); 
        System.out.println(binarySearch(numVec, userInput2));
        
        
        
    }
}