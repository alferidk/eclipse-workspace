/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;
import lab.*;
import project.*;

/**
 *
 * @author ankemal0
 */
public class Main { 
    public static void main(String[] args) {
        //Lab1.test(args);
        //Lab2.test();
        //Project1.test();
       // Lab3.test();
      //Lab4.test();
      //Lab5.test();
    	//Project2.test();
    	Lab6.test();
    	
      
} 
    
}
