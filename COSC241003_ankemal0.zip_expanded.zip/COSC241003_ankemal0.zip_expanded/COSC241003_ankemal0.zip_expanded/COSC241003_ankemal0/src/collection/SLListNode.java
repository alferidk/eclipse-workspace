package collection;

public class SLListNode {

		public Object data;
		public SLListNode next;
		
		public SLListNode (Object d, SLListNode n)
		     {

		data = d;
		next = n;
	    
	      }
	}
	 
	 