/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collection;

/**
 *
 * @author ankemal0
 */
public class MySearch {
    
    public MySearch(){
     
    }
    
          public static int linearSearchsorted (MyVector v, Comparable target){
              int j;
              for(j=0; j<v.size()&& target.compareTo(v.elementAt(j)) > 0; j++);
              if (j<v.size()){
                  
                  
                  if(target.compareTo(v.elementAt(j))==0){
                      
                      
                  return j;
          }
          }
              
              return -1;
            
}
  public static int binarySearch (MyVector v, Comparable target){
      
int first = 0, last = v.size(), middle;
   while ( first<=last ){

middle = (first+last)/ 2;
if(target.compareTo(v.elementAt(middle))<0)
last = middle-1;
else if (target.compareTo(v.elementAt(middle))>0)
first= middle+1;
else
return middle;
   }
return -1;
}

}

