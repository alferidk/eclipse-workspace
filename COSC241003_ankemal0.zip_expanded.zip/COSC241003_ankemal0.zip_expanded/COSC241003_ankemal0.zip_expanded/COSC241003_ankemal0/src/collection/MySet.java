package collection;
/**
 */
public class MySet extends MyVector implements Cloneable{
   
    /**
     * Default constructor
     */
    public MySet(){
        
        super();
    }
    
    /**
     * Function that returns the size of the set
     * @return returns the size of the set
     */
    public int cardinality(){
           
        return this.size;
    }
    
    /**
     * Functions that checks the complement between two sets
     * @param B is another set
     * @return returns a new set
     */
    public MySet complement( MySet B){
       MySet temp = new MySet();
       
       temp = this.clone();
       
       if( B.cardinality() == 0){
           
           return temp;
       }else{
           
           
           for ( int i = 0; i < B.size; i++){
                      
               if( temp.contains(B.elementAt(i))){
                   
                   temp.remove(B.elementAt(i));
               }
           }
       }
       
       return temp;
    }
    /**
     * Function that create a shallow copy of the original set
     * @Override MyVector clone method
     * @return clone set
     */
    public MySet clone(){
        
        MySet tempSet = new MySet();
        
        tempSet.ensureCapacity(this.size);
             
        for ( int i = 0; i < size; i++){
            
            tempSet.data[i] = this.data[i];
            
            tempSet.size  = this.size;
            
        }
        
        return tempSet;
    }
    /**
     * Function that add element to the set
     * @param element is the object element
     */
    public void add( Object element){    
       
        if (this.contains(element)){
            
            return;
        }
              this.append(element);  
             
    }
    /**
     * Function that get the intersection of a set
     * @param B is another set
     * @return returns a new set containing the elements that is common to both set
     */
    public MySet intersection( MySet B){
        
        MySet tempSet = new MySet();
        MySet newSet = new MySet();    
        tempSet = this.clone();      
        if( B.cardinality()==0){           
            return null;           
        }
        else {  
            for ( int i = 0; i < B.size; i++){          
                if(this.contains(B.elementAt(i))){
                    newSet.add(B.elementAt(i));
                }          
            }        
            return newSet;
        }       
    } 
    /**
     * Function that checks if one set is a subset of another set
     * @param B is another set
     * @return return true or false if one set is a subset of another
     */
   public boolean subsetOf( MySet B){
       
        int contains = 0;
        
        for(int i= 0;i< this.cardinality(); i++)
        {
            if(B.contains(this.elementAt(i)))
            {
                ++contains;
            }
        }
        if(contains == this.cardinality())
        {
            return true;
        }
        return false;
   }
   
   /**
    * Function that outputs the symmetrical difference of two sets
    * @param B is another set
    * @return returns a new set
    */
    public MySet symmetricDifference( MySet B){
        
       MySet temp1 = B.complement(this);
       MySet temp2 = this.complement(B);    
       MySet temp3 = temp1.union(temp2);
        
        return temp3;  
       
        }    
    /**
     * Function to get the union of two set
     * @param B is another set
     * @return returns the union of two set
     */
    public MySet union( MySet B){
        
         MySet tempSet = this.clone();
        
        for(int i = 0; i< B.cardinality(); i++)
        {
            tempSet.add(B.elementAt(i));
            
        }
        return tempSet;
    } 
    /**
     * String representation of MySet class
     * @return string representation
     */
    @Override
    public String toString()
    {
        String str = "+++++++++++++++++++++++++++++++++\n";
        str += "The current set contains the following:\n";
        str+= "Cardinality = " + size + "\n";
        str+= "Capacity = " + data.length +"\n";
        for (int i = 0; i< size; ++i) 
        {
            str+= i + ": "+ data[i] + "\t";
            if((i+1)%5==0) str+= "\n"; 
        }
        str += "\n+++++++++++++++++++++++++++++++++";
        return str;
    }
    
}
