/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collection;

/**
 *
 * @author Administrator
 */
public class MyVector implements Cloneable{
    
    
    protected Object[] data;
    
    protected static final int INITIAL_CAPACITY = 100;
            
            protected int size;
            
            public MyVector(){
                
                data = new Object[INITIAL_CAPACITY];
                
                size = 0;
            }
    
    /**
     * Function that expand the length of the data
     */
            public void expand(){
                
                Object [] newData = new Object[data.length * 2];
                
                for ( int i = 0; i < size; ++i){
                    
                    
                    newData[i] = data[i];
                }
                
                
                data = newData;
            }
            /**
             * Function that adds elements to the vector
             * @param element is the object element to be added to the vector
             */
            public void append(Object element){
                
                
                if( size==data.length)
                    
                    expand();
                
                data[size++] = element;
            }
            /**
             * Function that clear the elements from the vector
             */
            public void clear(){
                
                for( int i = 0; i <size; i++){
                    
                    
                    data[i] = null;
                
                    size = 0;
                }
            }
            /**
             * Function that checks if an element is present in the vector
             * @param element is the object element checking for if it is present in the vector
             * @return returns true if present or false if not present
             */
            public boolean contains( Object element){
                
                
                for ( int i = 0; i < size; i++){
                    
                    if( element.equals((data[i])))
                        
                       return true;
                }
                return false;
                }
            
            
            /**
             * Function that gets the element at a particular index
             * @param index is the index of the element we are looking for in the vector
             * @return returns the element at that index
             */
            public Object elementAt(int index){
                
                if( index < 0 || index >= size )
                    
                    return null;
                    
                    return data[index];
                }
            /**
             * Function that gets the index of the element
             * @param element is the Object element
             * @return returns the index of the element 
             */
            public int indexOf( Object element){
                
                for ( int i = 0; i < size; i++){
                    
                    if ( element.equals((data[i])))
                            return i;
                }
                return -1;
            }
            /**
             * Function that insert an element at a particular index
             * @param index is the index where the element is to be inserted
             * @param element is the Object element to be inserted at a particular index
             * @return return true if element has been inserted into that index
             */
            public boolean insertAt( int index, Object element){
                
                if ( index < 0 || index >=size)
                    return false;
                if( size==data.length)
                    expand();
                for ( int i = size; i > index; i--){
                    
                    
                    data[index] = element;
                    ++size;
                }
                  return true;
            
            }
           /**
            * Function that checks if the vector is empty
            * @return return vector size to 0 if empty
            */
public boolean isEmpty(){
      
   return size==0;
     
}
/**
 * Function that remove an element from a particular index
 * @param index is the index of the element to be removed
 * @return returns temp
 * 
 */
public Object removeAt( int index){
    
    if( index<0 || index>=size)
        return null;
    
    Object temp = data[index];
    
    while(index < size - 1){
        
        data[index] = data[index + 1];
        ++index;
    }
    
    data[--size] = null;
    
    return temp;
}
/**
 * Function that remove an object element from a vector
 * @param element is the element to be removed
 * @return the removed element
 */
public boolean remove( Object element){
    
    return removeAt(indexOf(element)) !=null;
}
/**
 * Function that replaces another element at a particular index
 * @param index is the index of the element to be replaced
 * @param element is element used to replace another element at a particular index
 * @return returns true if the element has been replaced
 */
public boolean replace( int index, Object element){
    
    if( index< 0 || index >= size)
        return false;
    data[index] = element;
    return true;
    
}
/**
 * Function that returns the size of the vector
 * @return return vector size
 */
public int size(){
    
    return size;
}

/**
 * Function that checks for the capacity of a vector
 * @param minCapacity is the minimum capacity 
 */
public void ensureCapacity( int minCapacity){
    
    if( minCapacity<=data.length -size)
        return;
    
    Object [] tempData = new Object[minCapacity + size];
    
    for( int i = 0; i < size; ++i){
        
        tempData[i] = data[i];
        
    }
    data =  tempData;
}

/**
 * Function that create a copy of the original vector
 * @return returns the cloned vector
 */
public MyVector clone(){
    
    MyVector vecCopy = new MyVector();
    
    vecCopy.ensureCapacity(this.size);
    
    for ( int i = 0; i < size; ++i){
        
        vecCopy.data[i] = this.data[i];
    }
    
    vecCopy.size = this.size;
    
    return vecCopy;
}
/**
 * Function that removes elements from a certain range
 * @param fromIndex is the beginning index of the elements to be removed
 * @param toIndex is the last index of the element to be removed
 */
public void removeRange( int fromIndex, int toIndex){
    
    if( fromIndex >= toIndex)
    return;
    
    if( fromIndex < 0)
        fromIndex = 0;
    
    if( toIndex >=size)
        toIndex = size;
    
    int num = toIndex - fromIndex;
    
    for( int i = fromIndex; i <size - num; ++i){
        
        data[i] = data[ i + num];
        
    }
    for ( int j = size - num; j < size; ++j){
        
        data[j] = null;
    }
    size-=num;
}
/**
 * Function that prints a string representation of the vector
 * @return a string representation of the vector
 */
public String toString(){
    
    String str = "+++++--------++++\n" + "The current vector contain the following = \n";
    
    str+= "Size " + size + "\n";
    
    str+="Total capacity = " + data.length + "\n";
    
    for ( int i = 0; i < size; ++i){
        
        str+=i + " : " + data[i] + "\t";
        
        if( (i + 1 ) % 5 == 0)
            str+="\n";
        
    }
    
    str +="\n++--------++\n";
    return str;
}
/**
 * Function that reverse the elements in a vector
 */
public void reverse(){
    
    Object temp;
    
    
    for (int i = 0; i < size/2; ++i){
        
        temp = data[i];
        
        data[i] = data[size - i - 1];
        
        data[size - i - 1] = temp;
    }
}
/**
 * Function that merge two vectors
 * @param vector2 is the second vector to be merged with the original vector
 */
public void merge( MyVector vector2){
    
    if( !vector2.isEmpty()){
        
        ensureCapacity(this.size + vector2.size());
        for ( int i = 0; i < vector2.size(); ++i){
            append(vector2.elementAt(i));
        }
    }else{
        
        System.out.println("Vector you are trying to merge is empty");
             }   
    
    }
}
