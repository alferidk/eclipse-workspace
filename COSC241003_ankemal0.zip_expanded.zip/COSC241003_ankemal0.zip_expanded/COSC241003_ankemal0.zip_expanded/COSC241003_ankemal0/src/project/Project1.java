/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import collection.MySet;

/**
 * Program to test set collection
 */
public class Project1 {
    
    /**
     * Program starting point
     */
    public static void test(){
            
        MySet  primeNumSet  = new MySet();
        MySet  fibonacciNumSet = new MySet();
        int num1 = 0;
        int num2 = 1;
        
        int num3;
        
        fibonacciNumSet.add(num1);//add the first 2 Fibonacci numbers 
        fibonacciNumSet.add(num2);     
        
        for ( int i = 1; i < 30; i++) {
            
            num3 = num1 + num2;           
            fibonacciNumSet.add(num3); //add the remaining 28 Fibonacci numbers making up 30 numbers   
            num1 = num2;
            num2 = num3;           
        }
        System.out.println("The content of  fibonacciNumSet sets");
        System.out.println(fibonacciNumSet.toString()); //print out the fibunacciNumSet
           
     int status = 1;//Adding prime numbers to PrimeNumSet
      int num = 2;
      
      for ( int i = 2 ; i <=31 ;  ){
         for ( int j = 2 ; j <= Math.sqrt(num) ; j++ ){
            if ( num%j == 0 ){
               status = 0;
               break;
            }
         }if ( status != 0 ){
             primeNumSet.add(num);            
             i++;
         }
         status = 1;
         num++;
      }      
      
      System.out.println("The content of  primeNumSet sets");
        System.out.println(primeNumSet.toString()); //print out the primeNumSet
        
        
        System.out.println("The Intersection of the two sets");
        MySet mIntersection = fibonacciNumSet.intersection(primeNumSet);//Intersection of the two sets
        System.out.println(mIntersection);//Print out the intersection
        
        System.out.println("The symmetric difference of the two sets");
        MySet mSymDiff = fibonacciNumSet.symmetricDifference(primeNumSet);//Symmetric difference
        System.out.println(mSymDiff.toString());//Prints the symmetric difference between the two sets
        
        System.out.println("The union of the two sets");
        MySet mUnion = fibonacciNumSet.union(primeNumSet);//Union of the two sets
        System.out.println(mUnion.toString());//Printing the union of the two sets
        
    }
    
}
