
import java.util.*;
import java.io.*;

public class Project2{

public String getNumber(Scanner input){

int [] phone_number = {2,2,2,3,3,3,4,4,4,5,5,5,6,6,6,7,7,7,7,8,8,8,9,9,9,9};

String user_inputs = input.next();
System.out.println("Please type in a 7 digit phone number");

String typed+number = "";

typed_number+=user_inputs;

int phone = Integer.valueOf(user_inputs);
if(isValidNumber(phone) && isValidLength(typed_number)){

if(validateInputs(phone)){



    //Implement logic to retrieve natching words from the dictionary
}


}

}


public String validateInputs(String inputs){

String num_word = "";
Switch(inputs){

    //Implement logic to add ["A-Z"] to the String and validate before matching with the 
    //corresponding dictionary words

Case2:


break;

Case3:

break;

Case4:

break;

Case5:

break;

Case6:

break;

Case7:

break;

Case8:

break;

Case9:

break;

Default:

num_word = "invalid";




}

}

public ArrayList<String> getDictionary(File f) throws IOException{

List<String> list = new ArrayList<>();
FileReader fr = new FileReader(f);
BufferedReader br = new BufferedReader(fr);

String words = "";

String lines = br.readLine();

while(lines != null){

list.add(lines.nextLine());
lines = br.readLine();

}

return list;
}


public boolean isValidNumber(int number){

boolean isValid = false;

    if(num > 1 && num <= 9){

        isValid = true;
    }

    return isValid;

}

public boolean isValidLength(String num){

isValidLen = false;

if( num.length() == 7){

    isValidLen = true;
}
return isValidLen;
}

}