package lab;
import java.util.*;

import collection.SLList;
import collection.SortedSLList;
/**
*
* @author ankemal0
*/

public class Lab6 {
public static void test (){
 
	SLList simpleList =new SLList();
	 
	for( int  i=0; i<31; i++ ) {
		int k = i*i; 
		 if (i%2==0) {
	  simpleList.insert(k);
	  
		  
	 }else {
	 simpleList.append(k);
	 
	}
	 
	}

  System.out.println(simpleList);
  
  simpleList.remove(25);
  simpleList.remove(36);
  simpleList.remove(64);
  simpleList.remove(100);
  simpleList.remove(400);
  
  System.out.println(simpleList);
  
  SortedSLList sortedList = new SortedSLList();
  for (int i = 0; i>31; i++) {
	  int g= i*i;
	  simpleList.insert(g);
	  
  }
	  System.out.println(simpleList);
	  
	  simpleList.remove( 1);
	  simpleList.remove(25);
	  simpleList.remove(36);
	  simpleList.remove(64);
	  simpleList.remove(144);
	  simpleList.remove(400);
	  simpleList.remove(900);
	  
	  System.out.println(sortedList);
	  
	  sortedList.insert(1);
	  sortedList.insert(64);
	  sortedList.insert(400);
	  sortedList.insert(900);
	  
	  System.out.println(sortedList);
}
  }
	  
  