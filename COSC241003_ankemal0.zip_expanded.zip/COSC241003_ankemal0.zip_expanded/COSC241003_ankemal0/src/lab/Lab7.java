 package lab;
import java.io.*;
import java.util.Random;

/**
*
* @author ankemal0
*/
import collection.*;
public class Lab7 {
	
	
	
	
       public static void test () throws IOException{
	
    	   Random rand = new Random();
           rand.setSeed(System.nanoTime());
           MyStack mystack= new MyStack();
           MyQueue myqueue=new MyQueue();
           
           for(int i=1; i<=60; i++) {
        	   int random=rand.nextInt();
        	  mystack.push(random);
        	  myqueue.insertBack(random);
           }
           for(int i=0; i<30;i++) {
        	   mystack.pop();
        	   myqueue.removeFront();
           }
           PrintStream output= new PrintStream("output.txt");
           //MyStack mystack=new MyStack();
           //MyQueue myqueue=new MyQueue();
           output.println(mystack.toString());
           output.println(myqueue.toString());
           
        	   
        	   
           }
           
          
	
}



