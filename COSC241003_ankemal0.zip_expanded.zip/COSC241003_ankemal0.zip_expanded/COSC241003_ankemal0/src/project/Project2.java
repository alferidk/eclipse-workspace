
import java.util.*;
import java.io.*;

public class Project2 {

	public String getNumber(Scanner input) {

		int[] phone_number = { 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 9, 9, 9, 9 };

		String user_inputs = input.next();
		System.out.println("Please type in a 7 digit phone number");

		String typed_number = "";

		typed_number += user_inputs;

		int phone = Integer.valueOf(user_inputs);
		if (isValidNumber(phone) && isValidLength(typed_number)) {

			/*if (validateInputs(phone)) {

				// Implement logic to retrieve natching words from the dictionary
			}*/

		}
		return typed_number;

	}

	public String validateInputs(String inputs) {

		String num_word = "";

		// Implement logic to add ["A-Z"] to the String and validate before matching
		// with the
		// corresponding dictionary words
		for (int i = 0; i < inputs.length(); i++) {

			char c = inputs.charAt(i);
			switch (c) {

			case 'a':
			case 'b':
			case 'c':
				num_word += 2;
				break;
			case 'd':
			case 'e':
			case 'f':
				num_word += 3;
				break;
			case 'g':
			case 'h':
			case 'i':
				num_word += 4;
				break;
			case 'j':
			case 'k':
			case 'l':
				num_word += 5;
				break;

			case 'm':
			case 'n':
			case 'o':
				num_word += 6;
				break;

			case 'p':
			case 'q':
			case 'r':
			case 's':
				num_word += 7;
				break;

			case 't':
			case 'u':
			case 'v':
				num_word += 8;
				break;

			case 'w':
			case 'x':
			case 'y':
			case 'z':
				num_word += 9;
				break;

			default:
				break;

			}

		}
		return num_word;

	}

	public String getMatch(List<String> dict, String words) {

		String word = "";

		for (int i = 0; i < dict.size(); i++) {

			String dict_word = dict.get(i);

			if (word.equalsIgnoreCase(dict_word)) {

				word += words;
			}

		}
		return word;

	}

	public List<String> getDictionary(File f) throws IOException {

		List<String> list = new ArrayList<>();
		FileReader fr = new FileReader(f);
		BufferedReader br = new BufferedReader(fr);

		String words = "";

		String lines = br.readLine();

		while (lines != null) {

			list.add(lines);
			lines = br.readLine();

		}

		return list;
	}

	public boolean isValidNumber(int num) {

		boolean isValid = false;

		if (num > 1 && num <= 9) {

			isValid = true;
		}

		return isValid;

	}

	public boolean isValidLength(String num) {

		boolean isValidLen = false;

		if (num.length() == 7) {

			isValidLen = true;
		}
		return isValidLen;
	}
	public static void main(String[] args) throws IOException {
		Project2 pg = new Project2();
		
	System.out.println(pg.getDictionary(new File("COSC241_P2_EnglishWordList.txt")));
	
	}

}