package collection;
public class MyStack {
		public SLListNode top;
		public boolean isEmpty(){
			return top == null;
			}
		public Object pop(){
		if(top == null){
		return null;
		}
		Object temp = top.data;
		top = top.next;
		return temp;
		}
		public void push(Object element){
		top = new SLListNode(element, top);
		}
		public Object top(){
		if(top == null){
		return null;
		}
		return top.data;
		}

  public String toString() {
	 
	 String out = "The SLList contain: ln";
	 if (top==null) {
		 return out + "o nodes";
	 }
	 else {
		 out +="heads->\t";
}
	 SLListNode ref=top;
	 while(ref.next!=null) {
    out += ref.data + "\t->\t";
		 ref= ref.next;
	 }
	 out += ref.data + "\t->null";
	 return out;
}
}


	


